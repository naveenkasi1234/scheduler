﻿using System;

namespace SchedulingJob.Model
{
    public class DashboardWidgetSchedulerModel
    {
        public int Id { get; set; }
        public int ClientId { get;set; }
        public enumSchedule ScheduleType { get; set; }
        public int WidgetId { get; set; }
        public string EmailDistributionList { get; set; }
        public int Benchmark { get; set; } = 0;
        public bool IsActive { get;set; }
        public string DateFlag { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string ChartTitle { get; set; }
        public long CreatedBy { get; set; }
    }

    public class DashboardResponseModel
    {
        public string DisplayName { get; set; }
        public int CountResult { get; set; }
        public string Trend { get; set; }
    }

    public enum enumSchedule
    {
        Daily = 0,
        Weekly = 1,
        Monthly = 2
    }
}