﻿using SchedulingJob.Helper;
using SchedulingJob.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Configuration.Install;
using System.ServiceProcess;
using System.Text;

namespace SchedulingJob
{
    public static  class Program
    {
        public const string ServiceName = "Dashboard Widget Service";

        #region Console Application
        static void Main(string[] args)
        {
            if (Environment.UserInteractive)
            {
                // running as consoleapp
                Start(args);
                Console.WriteLine("Press any key to stop...");
                Console.ReadKey(true);
                Stop();
            }
            else
            {
                Console.WriteLine("Running as service...");
                // running as service
                using (var service = new Service())
                    ServiceBase.Run(service);
            }
        }

        private static void Start(string[] args)
        {
            ExecuteDashboardWidgetScheduleJob();
        }

        private static void Stop()
        {
            // onstop code here
        }

        #endregion

        #region Window Service

        public class Service : ServiceBase
        {
            private System.Timers.Timer timer;
            private int interval = Convert.ToInt32(ConfigurationManager.AppSettings["interval"]);
            public Service()
            {
                ServiceName = Program.ServiceName;
            }

            protected override void OnStart(string[] args)
            {
                this.timer = new System.Timers.Timer();
                this.timer.Interval = interval * 60 * 1000;
                this.timer.AutoReset = true;
                this.timer.Enabled = true;
                this.timer.Start();
                this.timer.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent);
                //Program.Start(args);
                LogHelper.Write("OnStart: " + DateTime.Now);
            }

            protected override void OnStop()
            {
                //Program.Stop(args);
                LogHelper.Write("OnStop: " + DateTime.Now);
            }

            private void OnTimedEvent(object sender, EventArgs e)
            {
                LogHelper.Write("Execute Widget Scheduler: " + DateTime.Now);
                ExecuteDashboardWidgetScheduleJob();
            }
        }
        #endregion

        #region Execute Dashbord Widget Schedule Job

        private static void ExecuteDashboardWidgetScheduleJob()
        {
            List<DashboardWidgetSchedulerModel> _list = DatabaseHelper.GetScheduleJob();
            StringBuilder mailContent = new StringBuilder();
            mailContent.Append(" <table border=" + 1 + " cellpadding=" + 0 + " cellspacing=" + 0 + " width = " + 400 + "><tr><td align='center'><b>Chat Name</b></td><td align='center'><b>Benchmark</b></td><td align='center'> <b> Result Count</b> </td> <td align='center'><b> Duration/Trend</b></td><td align='center'><b> Date Range</b></td></tr>");
            foreach (DashboardWidgetSchedulerModel item in _list)
            {
                #region Start & end Date Range Identification
                DateTime startDateTime = DateTime.Now;
                DateTime endDateTime = DateTime.Now;
                if (item.DateFlag == "Yesterday")
                {
                    startDateTime = DateTime.Today.AddDays(-1);
                    endDateTime = DateTime.Today.AddDays(-1);
                }
                else if (item.DateFlag == "Last 7 Days")
                {
                    startDateTime = DateTime.Today.AddDays(-6);
                    //endDateTime = DateTime.Today;
                }
                else if (item.DateFlag == "Last 30 Days")
                {
                    startDateTime = DateTime.Today.AddDays(-29);
                    //endDateTime = DateTime.Today;
                }
                else if (item.DateFlag == "This Month")
                {
                    startDateTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                    endDateTime = startDateTime.AddMonths(1).AddDays(-1);
                }
                else if (item.DateFlag == "Last Month")
                {
                    startDateTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddMonths(-1);
                    endDateTime = startDateTime.AddDays(-1);
                }
                else if (item.DateFlag == "Custom Range")
                {
                    startDateTime = Convert.ToDateTime(item.StartDate);
                    endDateTime = Convert.ToDateTime(item.EndDate);
                }
                #endregion

                #region Get Create UserEmail
                string email = DatabaseHelper.GetEmployeeEmailByEmpSrId(item.CreatedBy);
                if (!string.IsNullOrEmpty(email))
                {
                    item.EmailDistributionList = email + ";" + item.EmailDistributionList;
                }
                #endregion

                List<DashboardResponseModel> resultList = DatabaseHelper.ExecuteWidgetProcess(item.WidgetId, item.Benchmark, startDateTime, endDateTime);
                if (resultList != null && resultList.Count > 0)
                {
                    item.StartDate = startDateTime;
                    item.EndDate = endDateTime;
                    MailHelper.SendMail(item, resultList);
                }
                mailContent.Append("<tr><td align='center'>" + item.ChartTitle + "</td><td align='center'>" + item.Benchmark + "</td><td align='center'>" + resultList.Count + "</td> <td align='center'>" + item.DateFlag + " </td> <td align='center'>" + startDateTime.ToShortDateString()  + "to" + endDateTime.ToShortDateString() + " </td></tr>");

                DatabaseHelper.InsertSchedulerLog(item.Id, item.ScheduleType);
                LogHelper.Write("Executed on " + DateTime.Now + " : ScheduleId:" + item.Id + " ClientId:" + item.ClientId + " Type:" + item.ScheduleType);
            }
            mailContent.Append("</table>");

            if (_list.Count > 0 && !string.IsNullOrEmpty(Convert.ToString(mailContent)))
            {
                #region Mail Process Started
                MailHelper.SendSummaryMail(ConfigurationManager.AppSettings["SummaryMailEmailList"], Convert.ToString(mailContent), "Dashboard Widget Summary");
                #endregion
            }
        }

        #endregion
    }

    [RunInstaller(true)]
    public class MyServiceInstaller : Installer
    {
        public MyServiceInstaller()
        {
            var spi = new ServiceProcessInstaller();
            var si = new ServiceInstaller();

            spi.Account = ServiceAccount.LocalSystem;
            spi.Username = null;
            spi.Password = null;

            si.DisplayName = Program.ServiceName;
            si.ServiceName = Program.ServiceName;
            si.StartType = ServiceStartMode.Automatic;

            Installers.Add(spi);
            Installers.Add(si);
        }
    }
}