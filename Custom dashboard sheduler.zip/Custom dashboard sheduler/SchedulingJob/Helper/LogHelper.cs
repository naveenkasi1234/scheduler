﻿using System;
using System.IO;
using System.Text;

namespace SchedulingJob.Helper
{
    public static class LogHelper
    {
        public static bool Write(string message)
        {
            bool Status = false;
            DateTime CurrentDateTime = DateTime.Now;
            string LogDirectory = AppDomain.CurrentDomain.BaseDirectory + "\\LogFiles\\";
            CheckCreateLogDirectory(LogDirectory);
            string logLine = BuildLogLine(CurrentDateTime, message);
            LogDirectory = (LogDirectory + "Log_" + LogFileName(CurrentDateTime) + ".txt");

            lock (typeof(LogHelper))
            {
                StreamWriter oStreamWriter = null;
                try
                {
                    oStreamWriter = new StreamWriter(LogDirectory, true);
                    oStreamWriter.WriteLine(logLine);
                    Status = true;
                }
                catch
                {

                }
                finally
                {
                    if (oStreamWriter != null)
                    {
                        oStreamWriter.Close();
                    }
                }
            }
            return Status;
        }

        private static bool CheckCreateLogDirectory(string LogPath)
        {
            bool loggingDirectoryExists = true;
            DirectoryInfo oDirectoryInfo = new DirectoryInfo(LogPath);
            try
            {
                if (!oDirectoryInfo.Exists)
                    Directory.CreateDirectory(LogPath);
            }
            catch (Exception)
            {
                loggingDirectoryExists = false;
            }            
            return loggingDirectoryExists;
        }

        private static string LogFileName(DateTime CurrentDateTime)
        {
            return CurrentDateTime.ToString("dd_MM_yyyy");
        }

        private static string BuildLogLine(DateTime CurrentDateTime, string LogMessage)
        {
            StringBuilder loglineStringBuilder = new StringBuilder();
            loglineStringBuilder.Append(LogFileEntryDateTime(CurrentDateTime));
            loglineStringBuilder.Append(" \t");
            loglineStringBuilder.Append(LogMessage);
            return loglineStringBuilder.ToString();
        }

        public static string LogFileEntryDateTime(DateTime CurrentDateTime)
        {
            return CurrentDateTime.ToString("dd-MM-yyyy HH:mm:ss");
        }
    }
}