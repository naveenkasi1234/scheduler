﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace SchedulingJob.Helper
{
    public static class AESCryptographyHelper
    {
        static string saultkey = "0m20MHN+TKJ8fAdUK15RnA==";
        static string aesuniquekey = "5E98B06C-2AF0-47EF-8585-A4F7CF3C4C77";
        public static string AES256DecryptText(string input)
        {
            int index = input.LastIndexOf("|");
            if (index != -1)
            {
                input = input.Remove(index, 1);
            }

            // Get the bytes of the string
            byte[] bytesToBeDecrypted = Convert.FromBase64String(input);
            byte[] aesuniquekeyBytes = Encoding.UTF8.GetBytes(aesuniquekey);
            aesuniquekeyBytes = SHA256.Create().ComputeHash(aesuniquekeyBytes);
            return Encoding.UTF8.GetString(AES_Decrypt(bytesToBeDecrypted, aesuniquekeyBytes));
        }

        private static byte[] AES_Decrypt(byte[] bytesToBeDecrypted, byte[] aesuniquekeyBytes)
        {
            byte[] decryptedBytes = null;

            // Set your salt here, change it to meet your flavor:
            // The salt bytes must be at least 8 bytes.
            byte[] saltBytes = Convert.FromBase64String(saultkey);

            using (MemoryStream ms = new MemoryStream())
            {
                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;
                    AES.Padding = PaddingMode.PKCS7;
                    var key = new Rfc2898DeriveBytes(aesuniquekeyBytes, saltBytes, 1000);
                    AES.Key = key.GetBytes(AES.KeySize / 8);
                    AES.IV = key.GetBytes(AES.BlockSize / 8);
                    AES.Mode = CipherMode.CBC;

                    using (var cs = new CryptoStream(ms, AES.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(bytesToBeDecrypted, 0, bytesToBeDecrypted.Length);
                        cs.Close();
                    }
                    decryptedBytes = ms.ToArray();
                }
            }

            return decryptedBytes;
        }
    }
}
