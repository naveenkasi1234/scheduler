﻿using Dapper;
using SchedulingJob.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Reflection;

namespace SchedulingJob.Helper
{
    public static class DatabaseHelper
    {
        public static string connectionString = Convert.ToString(ConfigurationManager.AppSettings["ConnectionString"]);
        public static List<DashboardWidgetSchedulerModel> GetScheduleJob()
        {
            List<DashboardWidgetSchedulerModel> objList = new List<DashboardWidgetSchedulerModel>();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    IEnumerable<DashboardWidgetSchedulerModel> lstDomain = connection.Query<DashboardWidgetSchedulerModel>(sql: "usp_GetDashboardWidgetSchedulerList", param: new DynamicParameters(), commandType: CommandType.StoredProcedure);
                    objList = lstDomain.ToList();
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objList;
        }
        public static void InsertSchedulerLog(int dashboardWidgetSchedulerId, enumSchedule scheduledType)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand sqlComm = new SqlCommand("usp_InsertDashboardWidgetSchedulerLog", connection);
                    sqlComm.CommandType = CommandType.StoredProcedure;
                    sqlComm.Parameters.Add("@DashboardWidgetSchedulerId", SqlDbType.Int).Value = dashboardWidgetSchedulerId;
                    sqlComm.Parameters.Add("@ScheduleType", SqlDbType.NVarChar).Value = Enum.GetName(typeof(enumSchedule), scheduledType) ;
                    sqlComm.ExecuteNonQuery();
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<DashboardResponseModel> ExecuteWidgetProcess(int widgetId, int benchmark, DateTime startDateTime, DateTime endDateTime)
        {
            List<DashboardResponseModel> objList = new List<DashboardResponseModel>();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    var param = new DynamicParameters();
                    param.Add("@WidgetId", widgetId);
                    param.Add("@Benchmark", benchmark);
                    param.Add("@StartDate", startDateTime.ToString("d", new CultureInfo(CultureInfo.CurrentUICulture.Name)));
                    param.Add("@EndDate", endDateTime.ToString("d", new CultureInfo(CultureInfo.CurrentUICulture.Name)));
                    IEnumerable<DashboardResponseModel> lstDomain = connection.Query<DashboardResponseModel>(sql: "usp_ProcessDashboardWidgetSchedulerData", param: param, commandType: CommandType.StoredProcedure);
                    objList = lstDomain.ToList();
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objList;
        }

        public static string GetEmployeeEmailByEmpSrId(long empSrId)
        {
            string email = string.Empty;
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    var param = new DynamicParameters();
                    param.Add("@Id", empSrId);
                    email = connection.QueryFirstOrDefault<string>(sql: "usp_GetEmployeeEmailIdByEmpSrId", param: param, commandType: CommandType.StoredProcedure);
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return email;
        }
    }
}