﻿using SchedulingJob.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net;
using System.Net.Mail;

namespace SchedulingJob.Helper
{
    public static class MailHelper
    {
        public static string from = ConfigurationManager.AppSettings["MailFrom"];
        public static string mailserver = ConfigurationManager.AppSettings["MailServer"];
        public static string mailusername = ConfigurationManager.AppSettings["MailUserName"];
        public static string mailpassword = AESCryptographyHelper.AES256DecryptText(ConfigurationManager.AppSettings["MailPassword"]);
        public static string port = ConfigurationManager.AppSettings["MailPort"];
        public static bool isssltrue = Convert.ToBoolean(ConfigurationManager.AppSettings["IsSSLTrue"]);
        public static string localMail = ConfigurationManager.AppSettings["SentLocalMail"];
        public static void SendMail(DashboardWidgetSchedulerModel item, List<DashboardResponseModel> response)
        {
            try
            {
                LogHelper.Write("Start send email for WidgetId: " + item.WidgetId);

                #region Mail Process Started
                string textBody = " <table border=" + 1 + " cellpadding=" + 0 + " cellspacing=" + 0 + " width = " + 400 + "><tr><td align='center'><b>DisplayName</b></td><td align='center'> <b> Count Result</b> </td></tr>";
                foreach (DashboardResponseModel data in response)
                {
                    textBody += "<tr><td align='center'>" + data.DisplayName + "</td><td align='center'>" + data.CountResult + " </td></tr>";
                }
                textBody += "</table>";

                #region Fill Value in Template
                string HtmlBody = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "\\Template\\WidgetDetailMailTemplate.html");
                HtmlBody = HtmlBody.Replace("@ChartTitle", item.ChartTitle);
                HtmlBody = HtmlBody.Replace("@Beanchmark", Convert.ToString(item.Benchmark));
                HtmlBody = HtmlBody.Replace("@DateFlag", item.DateFlag);
                HtmlBody = HtmlBody.Replace("@StartDate", item.StartDate.ToShortDateString());
                HtmlBody = HtmlBody.Replace("@EndDate", item.EndDate.ToShortDateString());
                HtmlBody = HtmlBody.Replace("@TableStructure", textBody);
                #endregion

                Send(item.EmailDistributionList, Convert.ToString(HtmlBody), "Dashboard Widget Processed: " + item.WidgetId);
                #endregion

                LogHelper.Write("Successfully sent email for WidgetId: " + item.WidgetId);
            }
            catch (Exception ex)
            {
                LogHelper.Write("Error : " + ex.Message + " WidgetId:" + item.WidgetId);
            }
        }

        public static void SendSummaryMail(string emailTo, string body, string subject)
        {
            try
            {
                LogHelper.Write("Start send summary email- " + DateTime.Now);

                #region Fill Value in Template
                string HtmlBody = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "\\Template\\WidgetSummaryMailTemplate.html");
                HtmlBody = HtmlBody.Replace("@TableStructure", body);
                #endregion

                Send(emailTo, Convert.ToString(HtmlBody), subject);
                
                LogHelper.Write("Successfully sent summary email" + DateTime.Now);
            }
            catch (Exception ex)
            {
                LogHelper.Write("Error : " + ex.Message + DateTime.Now);
            }
        }

        public static void Send(string toEmail, string message, string subject)
        {
            try
            {
                if (Convert.ToBoolean(ConfigurationManager.AppSettings["IsEnableMailSent"]))
                {
                    ServicePointManager.SecurityProtocol = ServicePointManager.SecurityProtocol | SecurityProtocolType.Tls12 | (SecurityProtocolType)768 | (SecurityProtocolType)3072;/* | System.Net.SecurityProtocolType.Ssl3;*/
                    var smtp = new SmtpClient();
                    {
                        smtp.Host = mailserver;
                        smtp.Port = Convert.ToInt16(port);
                        smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtp.Credentials = new NetworkCredential(mailusername, mailpassword);
                        smtp.EnableSsl = isssltrue;
                        smtp.Timeout = 200000000;
                    }
                    MailMessage mail = new MailMessage();
                    mail.From = new MailAddress(from);
                    if (!string.IsNullOrEmpty(localMail))
                    {
                        mail.To.Add(localMail);
                    }
                    else if (!string.IsNullOrEmpty(toEmail))
                    {
                        toEmail = toEmail.Replace("\r", "").Replace("\n", "").Replace("\t", "");
                        foreach (var address in toEmail.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                        {
                            mail.To.Add(address);
                        }
                    }
                    mail.Subject = subject;
                    mail.BodyEncoding = System.Text.Encoding.UTF8;
                    mail.IsBodyHtml = true;
                    mail.Body = message;
                    smtp.Send(mail);
                    mail.Dispose();
                }
            }
            catch (Exception ex)
            {
                LogHelper.Write("Error while sending email for WidgetId: " + subject);
            }
        }
    } 
}